<?php
require 'conn.php';
$tabName = "tab".$_POST['value']."_connectgrp";
//echo $tabName;
$sql= "SELECT number, maxgroup, influential  FROM ".$tabName;
//echo $sql;
$result = $conn->query($sql);
$data=array();
while($row = $result->fetchArray(SQLITE3_ASSOC)) {
		array_push($data, array($row['number'], $row['maxgroup'], $row['influential']));
				
}
header('Content-Type: application/json');
echo json_encode($data);
$conn->close();

?>

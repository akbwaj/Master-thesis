<?php
header('Content-Type: application/json');
$strCentrality = file_get_contents("centrality.json");
$itemCentrality = utf8_encode($strCentrality);
$decodeCentrality = json_decode($itemCentrality, true);

$strGlobalStats = file_get_contents("GlobalStatistics.json");
$itemGlobalStats = utf8_encode($strGlobalStats);
$decodeGlobalStats = json_decode($itemGlobalStats, true);
//print_r($decodeGlobalStats['globalInformation']);
//echo $itemGlobalStats;

function merge_json_decoded_arrays($decodeCentrality,$decodeGlobalStats) {
  $data = array();
  $arrayAB = array_merge($decodeCentrality['author_centralities'],$decodeGlobalStats['globalInformation']);
  foreach ($arrayAB as $value) {
    $authorName = strtoupper($value['author']);
    if (!isset($data[$authorName])) {
        $data[$authorName] = array();
        }
      $data[$authorName] = array_merge($data[$authorName],$value);
  }
  return ($data);
}
$merged_array = merge_json_decoded_arrays($decodeCentrality,$decodeGlobalStats);

$json = json_encode($merged_array);
$result = fixBadUnicodeForJson($json);
function fixBadUnicodeForJson($str) {
    $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3")).chr(hexdec("$4"))', $str);
    $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3"))', $str);
    $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2"))', $str);
    $str = preg_replace("/\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1"))', $str);
    return $str;
}
echo $result;
?>

<?php
//$dbuser = 'root';
//$dbpass = '';
//$dbhost = 'localhost';
//$dbname = 'thesis';

// Create connection
//$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);

// Check connection
//if ($conn->connect_error) {
//    die("Connection failed: " . $conn->connect_error);
//}


class MyDB extends SQLite3
{
    function __construct()
    {
        $this->open('thesis.db');
    }
}

$conn = new MyDB();
if(!$conn){
	echo $conn->lastEroorMsg();
}


?>

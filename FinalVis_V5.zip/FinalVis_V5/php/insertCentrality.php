
<?php
require 'conn.php';
header('Content-Type: application/json charset=utf-8');

//Read JSON	
$str = file_get_contents("centrality.json");
$item = utf8_encode($str);
$json = json_decode($item, true);
//echo print_r($json);
ini_set('max_execution_time', 2000); 
//Insert into tables
//echo $str['authorcitesAuthor'];
foreach ($json['author_centralities'] as $field) {
	$author = "'".$field['author']."'";
	$betweenessCentrality = $field['betweennessCentrality'];
	$DegreeCentrality = $field['DegreeCentrality'];
	$EigenvectorCentrality = $field['EigenvectorCentrality'];
	$IndegreeCentrality = $field['IndegreeCentrality'];
	$Outdegreecentrality = $field['Outdegreecentrality'];
	$ClosenessCentrality = $field['ClosenessCentrality'];
	$Eigenvectorcentralityrev = $field['Eigenvectorcentralityrev'];
		
	$sql = "INSERT INTO tab_centrality (author, betweenessCentrality, DegreeCentrality, EigenvectorCentrality, IndegreeCentrality, Outdegreecentrality, ClosenessCentrality, Eigenvectorcentralityrev)
	VALUES ($author, $betweenessCentrality, $DegreeCentrality, $EigenvectorCentrality, $IndegreeCentrality, $Outdegreecentrality, $ClosenessCentrality, $Eigenvectorcentralityrev)";
	//echo "<br>".$sql;
	if (!mysqli_query($conn, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

mysqli_close($conn);
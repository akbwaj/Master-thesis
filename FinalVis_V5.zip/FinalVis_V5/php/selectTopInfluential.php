<?php
require 'conn.php';
$tabName = "tab".$_POST['value']."_nodes";
$sql='SELECT titleLabel, indegreeVal FROM '.$tabName.' ORDER BY indegreeVal DESC LIMIT 20';
$result = $conn->query($sql);
$data=array();
while($row = $result->fetchArray(SQLITE3_ASSOC)) {
		array_push($data, array($row['titleLabel'], $row['indegreeVal']));
		//echo 	$row['titleLabel']." ".	$row['indegreeVal'];
    }

header('Content-Type: application/json');
echo json_encode($data);
$conn->close();

/*echo 'hisham';


//$tabName = 'tab13_nodes';
//echo $tabName;
$sql= 'SELECT titleLabel, indegreeVal FROM '.$tabName.' ORDER BY indegreeVal DESC LIMIT 20';
//$sql= 'SELECT titleLabel, indegreeVal FROM tab13_nodes ORDER BY indegreeVal DESC LIMIT 20';
//echo $sql;
$result = $conn->query($sql);
//echo $result;
$data=array();
foreach($result as $row) {
		array_push($data, array($row['titleLabel'], $row['indegreeVal']));
				
    }

header('Content-Type: application/json');
echo json_encode($data);

*/

?>

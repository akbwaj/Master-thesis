<?php
require 'conn.php';
$tabEdges = "tab".$_POST['value']."_edges";
$tabNodes = "tab".$_POST['value']."_nodes";
//echo $tabName;
$sqlEdges= "SELECT count(*) as edgesCount  FROM ".$tabEdges;
$sqlNodes= "SELECT count(*) as nodesCount FROM ".$tabNodes;

$resultEdges = mysqli_query($conn, $sqlEdges);
$resultNodes = mysqli_query($conn, $sqlNodes);
$data=array();
if (!$resultEdges || mysqli_num_rows($resultEdges) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($resultEdges)) {
		array_push($data, array($row['edgesCount']));
				
    }
}
else {
    echo "0 results for Edges";
}
 
 if (!$resultNodes || mysqli_num_rows($resultNodes) > 0) {
    // output data of each row
    while($row = mysqli_fetch_assoc($resultNodes)) {
		array_push($data, array($row['nodesCount']));
	
		}
}
else {
    echo "0 results for Nodes";
}
header('Content-Type: application/json');
echo json_encode($data);

mysqli_close($conn);

?>

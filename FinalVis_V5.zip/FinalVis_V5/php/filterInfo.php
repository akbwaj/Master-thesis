<?php
header('Content-Type: application/json');
$strCentrality = file_get_contents("info.json");
$itemCentrality = utf8_encode($strCentrality);
$decodeCentrality = json_decode($itemCentrality, true);

//echo $itemGlobalStats;
$data = array();
//print_r($decodeCentrality);
foreach ($decodeCentrality as $key => $value) {
  //foreach ($value as $key => $value) {
  if (array_key_exists("betweennessCentrality",$value))
  {
    //$topPapers=array_slice($value['papers'],5);
    if (array_key_exists("papers",$value))
    {
      if(is_array($value["papers"])){
        $value["papers"]=array_slice($value["papers"],0,10);
        if($value["sum"]>0){
          $pos = ($value["pos"] /  $value["sum"]) * 100;
          $value["pos"]=  number_format($pos, 2) ."%";

          $neu=  ($value["neu"]/  $value["sum"]) * 100;
          $value["neu"]=  number_format($neu, 2) ."%";

          $neg=  ($value["neg"]/  $value["sum"]) * 100;
          $value["neg"]=  number_format($neg, 2) ."%";
          //$sum=  $value["papers"];
        }
        else {
          //$pos = ($value["pos"] /  $value["sum"]) * 100;
          $value["pos"]=  $value["pos"] ."%";

          //$neu=  ($value["neu"]/  $value["sum"]) * 100;
          $value["neu"]=  $value["neu"] ."%";

          //$neg=  ($value["neg"]/  $value["sum"]) * 100;
          $value["neg"]=  $value["neg"] ."%";
        }
      }

      //array_push($value['papers'], $topPapers);

    }
    array_push($data, $value);
  }
  //}
}
//print_r($data);
$json = json_encode($data);
$result = fixBadUnicodeForJson($json);
function fixBadUnicodeForJson($str) {
  $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3")).chr(hexdec("$4"))', $str);
  $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3"))', $str);
  $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2"))', $str);
  $str = preg_replace("/\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1"))', $str);
  return $str;
}
echo $result;

// $json = json_encode($merged_array);
// $result = fixBadUnicodeForJson($json);
// function fixBadUnicodeForJson($str) {
//     $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3")).chr(hexdec("$4"))', $str);
//     $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2")).chr(hexdec("$3"))', $str);
//     $str = preg_replace("/\\\\u00([0-9a-f]{2})\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1")).chr(hexdec("$2"))', $str);
//     $str = preg_replace("/\\\\u00([0-9a-f]{2})/e", 'chr(hexdec("$1"))', $str);
//     return $str;
// }
// echo $result;

?>

<?php
$array1 = '[
{"PlayerID":"17794204","userName":"Vandiel","castleCount":"9","NotUpd":"1476253231000"},
{"PlayerID":"21532584","userName":"Mayland","castleCount":"1","NotUpd":"0"},
{"PlayerID":"21539896","userName":"Dana","castleCount":"9","NotUpd":"0"}
]';
$array2 = '[
{"PlayerID":"17794204","Trouble":"2"},
{"PlayerID":"21532584","Trouble":"0"},
{"PlayerID":"21539896","Trouble":"0"}
]';

$decode_one = json_decode($array1,TRUE);
$decode_two = json_decode($array2,TRUE);

function merge_json_decoded_arrays($decode_one,$decode_two) {
    $data = array();
    $arrayAB = array_merge($decode_one,$decode_two);
    foreach ($arrayAB as $value) {
      $id = $value['PlayerID'];
      if (!isset($data[$id])) {
        $data[$id] = array();
      }
      $data[$id] = array_merge($data[$id],$value);
    }
    return $data;
  }
$merged_array = merge_json_decoded_arrays($decode_one,$decode_two);
print_r($merged_array);
?>

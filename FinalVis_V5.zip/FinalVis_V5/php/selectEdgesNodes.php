<?php
require 'conn.php';
$tabEdges = "tab".$_POST['value']."_edges";
$tabNodes = "tab".$_POST['value']."_nodes";
//$tabEdges = "tab13_edges";
//$tabNodes = "tab13_nodes";
//echo $tabName;
$sqlEdges= "SELECT authorFrom as \"from\", authorTo as \"to\", title, label FROM ".$tabEdges;
//$sqlNodes= "SELECT titleLabel as \"label\", titleLabel||' ,Indegree:' || indegreeVal as \"title\", indegreeVal as value, id, grp as \"group\" FROM ".$tabNodes;
$sqlNodes= "SELECT titleLabel as \"label\", indegreeVal as value, id, grp as \"group\" FROM ".$tabNodes;
//echo $sqlNodes;
$resultEdges = $conn->query($sqlEdges);
$resultNodes = $conn->query($sqlNodes);

$data=array("edges" => array(), "nodes" => array());
    while($row = $resultEdges->fetchArray(SQLITE3_ASSOC)) {
		array_push($data['edges'], $row);
     	}

   while($row = $resultNodes->fetchArray(SQLITE3_ASSOC)) {
    // $rowData=array( "label"=>$row['label'], "title_hidden"=>$row['title'], "value"=>(int)$row['value'], "id"=>$row['id'], "group"=>$row['group']);
    $rowData=array( "label"=>$row['label'], "value"=>(int)$row['value'], "id"=>$row['id'], "group"=>$row['group']);
		array_push($data['nodes'], $row);

	}

header('Content-Type: application/json');
echo json_encode($data);
$conn->close();

?>

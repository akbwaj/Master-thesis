
<?php
require 'conn.php';

//Create tables 
$sql = "CREATE TABLE tab5_edges (
 authorFrom int(11) NOT NULL,
 authorTo int(11) NOT NULL,
 title int(11) NOT NULL,
 label int(11) NOT NULL
)";
if (!mysqli_query($conn, $sql)) {
    echo "Error creating table: " . mysqli_error($conn);
}

$sql = "CREATE TABLE tab5_nodes (
 indegreeVal int(11) NOT NULL,
 titleLabel varchar(25) NOT NULL,
 id int(11) NOT NULL,
 grp int(11) NOT NULL
) ";
if (!mysqli_query($conn, $sql)) {
    echo "Error creating table: " . mysqli_error($conn);
}

$sql = "CREATE TABLE tab5_connectgrp (
 number int(11) NOT NULL,
 maxgroup int(11) NOT NULL,
 influential varchar(25) NOT NULL
)";
if (!mysqli_query($conn, $sql)) {
    echo "Error creating table: " . mysqli_error($conn);
}

//Read JSON	
$str = file_get_contents("nodesData/nodes5.json");
$json = json_decode($str, true);
echo "table 5"."<br>";
echo "Edges".sizeof($json['edges'])."<br>";
echo "Nodes".sizeof($json['nodes'])."<br>";
ini_set('max_execution_time', 2000); 

//Insert into tables
foreach ($json['edges'] as $field) {
	$from = (int)$field['from'];
	$to = (int)$field['to'];
	$title = (int)$field['title'];
	$label = (int)$field['label'];
	
	$sql = "INSERT INTO tab5_edges (authorFrom, authorTo, title, label)
	VALUES ($from, $to, $title, $label)";
	//echo "<br>".$sql;
	if (!mysqli_query($conn, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

foreach ($json['nodes'] as $field) {
	$title= substr($field['title'], 0, stripos($field['title'], ','));
	$indegree = substr($field['title'], strrpos($field['title'],':')+1);
	$indegreeVal = (int)$field['value'];
	$titleLabel = "'".$field['label']."'";
	$id = (int)$field['id'];
	$group = (int)$field['group'];
	$sql = "INSERT INTO tab5_nodes (indegreeVal, titleLabel, id, grp)
	VALUES ( $indegreeVal, $titleLabel, $id, $group)";
	//echo $sql."<br>";
	if (!mysqli_query($conn, $sql)) {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

foreach ($json['connectedgroups'] as $field) {
	$number = $field['number'];
	$maxgroup = $field['maxgroup'];
	$influential = "'".$field['influential']."'";
	$sql = "INSERT INTO tab5_connectgrp (number, maxgroup, influential)
	VALUES ($number, $maxgroup, $influential)";
	if (!mysqli_query($conn, $sql)) {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}

mysqli_close($conn);
?>

<?php
header('Content-Type: application/json');
$strCentrality = file_get_contents("centrality.json");
$itemCentrality = utf8_encode($strCentrality);
$decodeCentrality = json_decode($itemCentrality, true);

$strGlobalStats = file_get_contents("filteredInfo.json");
$itemGlobalStats = utf8_encode($strGlobalStats);
$filterInfo = json_decode($itemGlobalStats, true);
$flag="Yes";
//print_r($decodeCentrality["author_centralities"]);
foreach ($decodeCentrality["author_centralities"] as $key => $value) {

  //print_r($value["author"]);
  //echo "\n";
  foreach ($filterInfo as $key => $valuefilterInfo) {
    //print_r($valuefilterInfo["author"]);
    if($value["author"] == strtoupper($valuefilterInfo["author"])){
      //print_r($value["author"]."====". $valuefilterInfo["author"]);
      //echo "\n";
      $flag="Yes";
      break;

    }
    else {
      $flag="No";
    }
  }
  if ($flag=="No") {
    print_r($value["author"]);
    echo "\n";
  }
}


?>
